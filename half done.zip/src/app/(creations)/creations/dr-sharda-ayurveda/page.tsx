"use client"

import React, { useRef } from 'react';
import { useScroll, useTransform, motion } from 'framer-motion';
import H1Card from '@/components/workCompo/heading'
import HeadPara from '@/components/workCompo/highLights'
import ImageCard from '@/components/workCompo/imgCard'
import List from '@/components/workCompo/list'
import ShowCas from '@/components/workCompo/showcasing'

import styles from './styles.module.scss';

export default function DrShardaPage(){

    const container = useRef(null);
    const { scrollYProgress } = useScroll({
        target: container,
        offset: ["start end", "end start"]
    })

    const height = useTransform(scrollYProgress, [0, 0.9], [50, 0])

    return(
        <div ref={container} className={styles.slidingImages}>
            <main className="mt-[10vw] mb-[5vh] flex justify-center items-center overflow-y-auto">
                <div className="w-[1200px] flex flex-col">
                    <div className="flex flex-col justify-center">
                        <H1Card
                            subHeading="Dr. Sharda Ayurveda"
                            H1="Strategic Redesign for Enhanced Simplicity in Eyowo Mobile Finance App"
                        />
                        <ImageCard
                            alttitle="Beautiful Landscape"
                            imageUrl="/images/dr-sharda-ayurveda.png"
                            altText="A beautiful landscape"
                            className="relative mt-[3vh] w-[100%] h-[60vh] rounded-[10px] shadow-xl"                  
                        />
                    </div>
                    <div className="">
                        <HeadPara
                            H2="Introduction"
                            Para="The project involved working on the website DrShardayurveda.org with a focus on enhancing user experience (UX), implementing on-page SEO strategies, and contributing to the development process. This website serves as an upgraded version of DrShardaayurveda.com, with the aim of transitioning from the existing platform to this new iteration."
                        />

                        <List
                            H2="Scope of Work"
                        
                            b1="User Experience (UX) Enhancement"
                            l1="Conducted thorough assessments of the website's usability and user interface design. Implemented UX improvements to enhance the overall browsing experience, including optimising navigation, improving accessibility, and ensuring consistency in design elements."
                        
                            b2="On-Page SEO Optimization"
                            l2="Implemented on-page SEO techniques to improve the website's search engine rankings and visibility. This involved optimising meta tags, headings, and content structure to align with relevant keywords and improve organic search performance."
                            
                            b3="Website Development Contribution"
                            l3="Utilised expertise in ReactJS, HTML, CSS, and JavaScript to contribute to the development of the website. Collaborated with the development team to implement design enhancements, improve functionality, and ensure compatibility across various devices and browsers."
                        />
                        
                        <HeadPara
                            H2="Challenges Faced"
                            Para="One of the challenges encountered during the project was ensuring a seamless transition from the previous website to the upgraded version while maintaining consistency in branding, content, and functionality. Additionally, balancing the implementation of UX improvements with on-page SEO optimization without compromising one over the other required careful consideration and strategic planning."
                        />

                        <List
                            H2="Contributions and Achievements"

                            b1="Enhanced User Experience"
                            l1="Implemented UX enhancements resulting in improved usability, navigation, and overall user satisfaction."
                            
                            b2="On-Page SEO Optimization"
                            l2="Optimised website content and structure to improve search engine visibility and rankings."
                            
                            b3="Development Contributions"
                            l3="Contributed to the development process with expertise in ReactJS, HTML, CSS, and JavaScript, ensuring a seamless and responsive website experience across devices."
                        />

                        <HeadPara
                            H2="Project Status"
                            Para="As this website serves as an upgrade project from DrShardaayurveda.com, it is still in the process of development and refinement. While significant strides have been made in terms of UX enhancements, on-page SEO optimization, and development contributions, further iterations and adjustments may be required to achieve the desired outcome."
                        />

                        <ShowCas
                            H2="Observations"

                            b1="80%"
                            p1="Struggled to navigate the homepage and locating specific actions proved challenging."
                            
                            b2="60%"
                            p2="Faced difficulties in understanding the process to top up their wallet."
                            
                            b3="75%"
                            p3="Were unaware of services rendered, pointing to a need for better location and communication." 
                            
                            b4="65%"
                            p4="Expressed frustration over the lengthy process required to execute an action."
                        />
                    </div>
                </div>
            </main>
            <motion.div style={{height}} className={styles.circleContainer}>
                <div className={styles.circle}></div>
            </motion.div>
        </div>
    )
}
